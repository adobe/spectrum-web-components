"use strict";
(self["webpackChunk_spectrum_web_components_1st_gen"] = self["webpackChunk_spectrum_web_components_1st_gen"] || []).push([["status-light-stories-status-light-stories"],{

/***/ "../2nd-gen/packages/core/dist/components/status-light/StatusLight.base.js":
/*!*********************************************************************************!*\
  !*** ../2nd-gen/packages/core/dist/components/status-light/StatusLight.base.js ***!
  \*********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StatusLightBase: function() { return /* binding */ d; }
/* harmony export */ });
/* harmony import */ var lit_decorators_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lit/decorators.js */ "../node_modules/lit/decorators.js");
/* harmony import */ var _spectrum_web_components_core_shared_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @spectrum-web-components/core/shared/base */ "../2nd-gen/packages/core/dist/shared/base/index.js");


var u = Object.defineProperty, c = (o, s, e, l) => {
  for (var t = void 0, i = o.length - 1, r; i >= 0; i--)
    (r = o[i]) && (t = r(s, e, t) || t);
  return t && u(s, e, t), t;
};
class d extends (0,_spectrum_web_components_core_shared_base__WEBPACK_IMPORTED_MODULE_1__.SizedMixin)(_spectrum_web_components_core_shared_base__WEBPACK_IMPORTED_MODULE_1__.SpectrumElement, {
  noDefaultSize: !0
}) {
  constructor() {
    super(...arguments), this.variant = "info";
  }
  // ──────────────────────
  //     IMPLEMENTATION
  // ──────────────────────
  updated(s) {
    if (super.updated(s), window.__swc?.DEBUG) {
      const e = this.constructor;
      e.VARIANTS.includes(this.variant) || window.__swc.warn(
        this,
        `<${this.localName}> element expects the "variant" attribute to be one of the following:`,
        "https://opensource.adobe.com/spectrum-web-components/components/status-light/#variants",
        {
          issues: [...e.VARIANTS]
        }
      ), this.hasAttribute("disabled") && !("disabled" in this) && window.__swc.warn(
        this,
        `<${this.localName}> element does not support the disabled state.`,
        "https://opensource.adobe.com/spectrum-web-components/components/status-light/#states",
        {
          issues: [
            "disabled is not a supported property in Spectrum 2"
          ]
        }
      );
    }
  }
}
c([
  (0,lit_decorators_js__WEBPACK_IMPORTED_MODULE_0__.property)({ type: String, reflect: !0 })
], d.prototype, "variant");

//# sourceMappingURL=StatusLight.base.js.map


/***/ }),

/***/ "../2nd-gen/packages/core/dist/components/status-light/StatusLight.types.js":
/*!**********************************************************************************!*\
  !*** ../2nd-gen/packages/core/dist/components/status-light/StatusLight.types.js ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   STATUSLIGHT_VARIANTS_COLOR_S1: function() { return /* binding */ S; },
/* harmony export */   STATUSLIGHT_VARIANTS_COLOR_S2: function() { return /* binding */ _; },
/* harmony export */   STATUSLIGHT_VARIANTS_S1: function() { return /* binding */ e; },
/* harmony export */   STATUSLIGHT_VARIANTS_S2: function() { return /* binding */ o; },
/* harmony export */   STATUSLIGHT_VARIANTS_SEMANTIC: function() { return /* binding */ T; },
/* harmony export */   STATUSLIGHT_VARIANTS_SEMANTIC_S1: function() { return /* binding */ A; },
/* harmony export */   STATUSLIGHT_VARIANTS_SEMANTIC_S2: function() { return /* binding */ n; }
/* harmony export */ });
const T = [
  "neutral",
  "info",
  "positive",
  "negative",
  "notice"
], A = [
  ...T,
  "accent"
], n = [
  ...T
], S = [
  "fuchsia",
  "indigo",
  "magenta",
  "purple",
  "seafoam",
  "yellow",
  "chartreuse",
  "celery",
  "cyan"
], _ = [
  ...S,
  "pink",
  "turquoise",
  "brown",
  "cinnamon",
  "silver"
], e = [
  ...A,
  ...S
], o = [
  ...n,
  ..._
];

//# sourceMappingURL=StatusLight.types.js.map


/***/ }),

/***/ "../2nd-gen/packages/core/dist/components/status-light/index.js":
/*!**********************************************************************!*\
  !*** ../2nd-gen/packages/core/dist/components/status-light/index.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   STATUSLIGHT_VARIANTS_COLOR_S1: function() { return /* reexport safe */ _StatusLight_types_js__WEBPACK_IMPORTED_MODULE_1__.STATUSLIGHT_VARIANTS_COLOR_S1; },
/* harmony export */   STATUSLIGHT_VARIANTS_COLOR_S2: function() { return /* reexport safe */ _StatusLight_types_js__WEBPACK_IMPORTED_MODULE_1__.STATUSLIGHT_VARIANTS_COLOR_S2; },
/* harmony export */   STATUSLIGHT_VARIANTS_S1: function() { return /* reexport safe */ _StatusLight_types_js__WEBPACK_IMPORTED_MODULE_1__.STATUSLIGHT_VARIANTS_S1; },
/* harmony export */   STATUSLIGHT_VARIANTS_S2: function() { return /* reexport safe */ _StatusLight_types_js__WEBPACK_IMPORTED_MODULE_1__.STATUSLIGHT_VARIANTS_S2; },
/* harmony export */   STATUSLIGHT_VARIANTS_SEMANTIC: function() { return /* reexport safe */ _StatusLight_types_js__WEBPACK_IMPORTED_MODULE_1__.STATUSLIGHT_VARIANTS_SEMANTIC; },
/* harmony export */   STATUSLIGHT_VARIANTS_SEMANTIC_S1: function() { return /* reexport safe */ _StatusLight_types_js__WEBPACK_IMPORTED_MODULE_1__.STATUSLIGHT_VARIANTS_SEMANTIC_S1; },
/* harmony export */   STATUSLIGHT_VARIANTS_SEMANTIC_S2: function() { return /* reexport safe */ _StatusLight_types_js__WEBPACK_IMPORTED_MODULE_1__.STATUSLIGHT_VARIANTS_SEMANTIC_S2; },
/* harmony export */   StatusLightBase: function() { return /* reexport safe */ _StatusLight_base_js__WEBPACK_IMPORTED_MODULE_0__.StatusLightBase; }
/* harmony export */ });
/* harmony import */ var _StatusLight_base_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StatusLight.base.js */ "../2nd-gen/packages/core/dist/components/status-light/StatusLight.base.js");
/* harmony import */ var _StatusLight_types_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./StatusLight.types.js */ "../2nd-gen/packages/core/dist/components/status-light/StatusLight.types.js");



//# sourceMappingURL=index.js.map


/***/ }),

/***/ "../2nd-gen/packages/core/dist/shared/base/index.js":
/*!**********************************************************!*\
  !*** ../2nd-gen/packages/core/dist/shared/base/index.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ElementSizes: function() { return /* reexport safe */ _sizedMixin_js__WEBPACK_IMPORTED_MODULE_1__.ElementSizes; },
/* harmony export */   SizedMixin: function() { return /* reexport safe */ _sizedMixin_js__WEBPACK_IMPORTED_MODULE_1__.SizedMixin; },
/* harmony export */   SpectrumElement: function() { return /* reexport safe */ _Base_js__WEBPACK_IMPORTED_MODULE_0__.SpectrumElement; },
/* harmony export */   SpectrumMixin: function() { return /* reexport safe */ _Base_js__WEBPACK_IMPORTED_MODULE_0__.SpectrumMixin; },
/* harmony export */   defineElement: function() { return /* reexport safe */ _define_element_js__WEBPACK_IMPORTED_MODULE_2__.defineElement; },
/* harmony export */   version: function() { return /* reexport safe */ _version_js__WEBPACK_IMPORTED_MODULE_3__.version; }
/* harmony export */ });
/* harmony import */ var _Base_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Base.js */ "../2nd-gen/packages/core/dist/shared/base/Base.js");
/* harmony import */ var _sizedMixin_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sizedMixin.js */ "../2nd-gen/packages/core/dist/shared/base/sizedMixin.js");
/* harmony import */ var _define_element_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./define-element.js */ "../2nd-gen/packages/core/dist/shared/base/define-element.js");
/* harmony import */ var _version_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./version.js */ "../2nd-gen/packages/core/dist/shared/base/version.js");





//# sourceMappingURL=index.js.map


/***/ }),

/***/ "./packages/status-light/sp-status-light.dev.js":
/*!******************************************************!*\
  !*** ./packages/status-light/sp-status-light.dev.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _src_StatusLight_dev_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./src/StatusLight.dev.js */ "./packages/status-light/src/StatusLight.dev.js");
/* harmony import */ var _spectrum_web_components_base_src_define_element_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @spectrum-web-components/base/src/define-element.js */ "./tools/base/src/define-element.dev.js");



(0,_spectrum_web_components_base_src_define_element_js__WEBPACK_IMPORTED_MODULE_1__.defineElement)("sp-status-light", _src_StatusLight_dev_js__WEBPACK_IMPORTED_MODULE_0__.StatusLight);
//# sourceMappingURL=sp-status-light.dev.js.map


/***/ }),

/***/ "./packages/status-light/src/StatusLight.dev.js":
/*!******************************************************!*\
  !*** ./packages/status-light/src/StatusLight.dev.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   STATUSLIGHT_VARIANTS: function() { return /* binding */ STATUSLIGHT_VARIANTS; },
/* harmony export */   StatusLight: function() { return /* binding */ StatusLight; }
/* harmony export */ });
/* harmony import */ var _spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @spectrum-web-components/base */ "./tools/base/src/index.dev.js");
/* harmony import */ var _spectrum_web_components_base_src_decorators_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @spectrum-web-components/base/src/decorators.js */ "./tools/base/src/decorators.dev.js");
/* harmony import */ var _spectrum_web_components_core_components_status_light__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @spectrum-web-components/core/components/status-light */ "../2nd-gen/packages/core/dist/components/status-light/index.js");
/* harmony import */ var _status_light_css_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./status-light.css.js */ "./packages/status-light/src/status-light.css.js");

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};




const STATUSLIGHT_VARIANTS = _spectrum_web_components_core_components_status_light__WEBPACK_IMPORTED_MODULE_2__.STATUSLIGHT_VARIANTS_S1;
class StatusLight extends _spectrum_web_components_core_components_status_light__WEBPACK_IMPORTED_MODULE_2__.StatusLightBase {
  constructor() {
    super(...arguments);
    this.variant = "info";
    this.disabled = false;
  }
  // ──────────────────────
  //     IMPLEMENTATION
  // ──────────────────────
  updated(changes) {
    super.updated(changes);
    if (changes.has("disabled")) {
      if (this.disabled) {
        this.setAttribute("aria-disabled", "true");
      } else {
        this.removeAttribute("aria-disabled");
      }
    }
  }
  // ──────────────────────────────
  //     RENDERING & STYLING
  // ──────────────────────────────
  static get styles() {
    return [_status_light_css_js__WEBPACK_IMPORTED_MODULE_3__["default"]];
  }
  render() {
    return (0,_spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__.html)`
            <slot></slot>
        `;
  }
}
// ────────────────────
//     API OVERRIDES
// ────────────────────
/**
 * @internal
 */
StatusLight.VARIANTS_COLOR = _spectrum_web_components_core_components_status_light__WEBPACK_IMPORTED_MODULE_2__.STATUSLIGHT_VARIANTS_COLOR_S1;
/**
 * @internal
 */
StatusLight.VARIANTS_SEMANTIC = _spectrum_web_components_core_components_status_light__WEBPACK_IMPORTED_MODULE_2__.STATUSLIGHT_VARIANTS_SEMANTIC_S1;
/**
 * @internal
 */
StatusLight.VARIANTS = _spectrum_web_components_core_components_status_light__WEBPACK_IMPORTED_MODULE_2__.STATUSLIGHT_VARIANTS_S1;
__decorateClass([
  (0,_spectrum_web_components_base_src_decorators_js__WEBPACK_IMPORTED_MODULE_1__.property)({ type: String, reflect: true })
], StatusLight.prototype, "variant", 2);
__decorateClass([
  (0,_spectrum_web_components_base_src_decorators_js__WEBPACK_IMPORTED_MODULE_1__.property)({ type: Boolean, reflect: true })
], StatusLight.prototype, "disabled", 2);
//# sourceMappingURL=StatusLight.dev.js.map


/***/ }),

/***/ "./packages/status-light/src/status-light.css.js":
/*!*******************************************************!*\
  !*** ./packages/status-light/src/status-light.css.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @spectrum-web-components/base */ "./tools/base/src/index.dev.js");
const s=(0,_spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__.css)`
    :host([dir]),:host{--spectrum-statuslight-height:var(--spectrum-component-height-100);--spectrum-statuslight-dot-size:var(--spectrum-status-light-dot-size-medium);--spectrum-statuslight-font-size:var(--spectrum-font-size-100);--spectrum-statuslight-spacing-dot-to-label:var(--spectrum-text-to-visual-100);--spectrum-statuslight-spacing-top-to-dot:var(--spectrum-status-light-top-to-dot-medium);--spectrum-statuslight-spacing-top-to-label:var(--spectrum-component-top-to-text-100);--spectrum-statuslight-spacing-bottom-to-label:var(--spectrum-component-bottom-to-text-100)}:host([size=s]){--spectrum-statuslight-height:var(--spectrum-component-height-75);--spectrum-statuslight-dot-size:var(--spectrum-status-light-dot-size-small);--spectrum-statuslight-font-size:var(--spectrum-font-size-75);--spectrum-statuslight-spacing-dot-to-label:var(--spectrum-text-to-visual-75);--spectrum-statuslight-spacing-top-to-dot:var(--spectrum-status-light-top-to-dot-small);--spectrum-statuslight-spacing-top-to-label:var(--spectrum-component-top-to-text-75);--spectrum-statuslight-spacing-bottom-to-label:var(--spectrum-component-bottom-to-text-75)}:host([size=l]){--spectrum-statuslight-height:var(--spectrum-component-height-200);--spectrum-statuslight-dot-size:var(--spectrum-status-light-dot-size-large);--spectrum-statuslight-font-size:var(--spectrum-font-size-200);--spectrum-statuslight-spacing-dot-to-label:var(--spectrum-text-to-visual-200);--spectrum-statuslight-spacing-top-to-dot:var(--spectrum-status-light-top-to-dot-large);--spectrum-statuslight-spacing-top-to-label:var(--spectrum-component-top-to-text-200);--spectrum-statuslight-spacing-bottom-to-label:var(--spectrum-component-bottom-to-text-200)}:host([size=xl]){--spectrum-statuslight-height:var(--spectrum-component-height-300);--spectrum-statuslight-dot-size:var(--spectrum-status-light-dot-size-extra-large);--spectrum-statuslight-font-size:var(--spectrum-font-size-300);--spectrum-statuslight-spacing-dot-to-label:var(--spectrum-text-to-visual-300);--spectrum-statuslight-spacing-top-to-dot:var(--spectrum-status-light-top-to-dot-extra-large);--spectrum-statuslight-spacing-top-to-label:var(--spectrum-component-top-to-text-300);--spectrum-statuslight-spacing-bottom-to-label:var(--spectrum-component-bottom-to-text-300)}:host([dir]){--spectrum-statuslight-corner-radius:50%;--spectrum-statuslight-font-weight:400;--spectrum-statuslight-border-width:var(--spectrum-border-width-100);--spectrum-statuslight-line-height:var(--spectrum-line-height-100);--spectrum-statuslight-line-height-cjk:var(--spectrum-cjk-line-height-100);--spectrum-statuslight-content-color-default:var(--spectrum-neutral-content-color-default);--spectrum-statuslight-subdued-content-color-default:var(--spectrum-neutral-subdued-content-color-default);--spectrum-statuslight-semantic-neutral-color:var(--spectrum-neutral-visual-color);--spectrum-statuslight-semantic-accent-color:var(--spectrum-accent-visual-color);--spectrum-statuslight-semantic-negative-color:var(--spectrum-negative-visual-color);--spectrum-statuslight-semantic-info-color:var(--spectrum-informative-visual-color);--spectrum-statuslight-semantic-notice-color:var(--spectrum-notice-visual-color);--spectrum-statuslight-semantic-positive-color:var(--spectrum-positive-visual-color);--spectrum-statuslight-nonsemantic-gray-color:var(--spectrum-gray-visual-color);--spectrum-statuslight-nonsemantic-red-color:var(--spectrum-red-visual-color);--spectrum-statuslight-nonsemantic-orange-color:var(--spectrum-orange-visual-color);--spectrum-statuslight-nonsemantic-yellow-color:var(--spectrum-yellow-visual-color);--spectrum-statuslight-nonsemantic-chartreuse-color:var(--spectrum-chartreuse-visual-color);--spectrum-statuslight-nonsemantic-celery-color:var(--spectrum-celery-visual-color);--spectrum-statuslight-nonsemantic-green-color:var(--spectrum-green-visual-color);--spectrum-statuslight-nonsemantic-seafoam-color:var(--spectrum-seafoam-visual-color);--spectrum-statuslight-nonsemantic-cyan-color:var(--spectrum-cyan-visual-color);--spectrum-statuslight-nonsemantic-blue-color:var(--spectrum-blue-visual-color);--spectrum-statuslight-nonsemantic-indigo-color:var(--spectrum-indigo-visual-color);--spectrum-statuslight-nonsemantic-purple-color:var(--spectrum-purple-visual-color);--spectrum-statuslight-nonsemantic-fuchsia-color:var(--spectrum-fuchsia-visual-color);--spectrum-statuslight-nonsemantic-magenta-color:var(--spectrum-magenta-visual-color);min-block-size:var(--mod-statuslight-height,var(--spectrum-statuslight-height));box-sizing:border-box;font-size:var(--mod-statuslight-font-size,var(--spectrum-statuslight-font-size));font-weight:400;font-weight:var(--mod-statuslight-font-weight,var(--spectrum-statuslight-font-weight));line-height:var(--mod-statuslight-line-height,var(--spectrum-statuslight-line-height));color:var(--highcontrast-statuslight-content-color-default,var(--mod-statuslight-content-color-default,var(--spectrum-statuslight-content-color-default)));flex-direction:row;align-items:flex-start;padding-block-start:var(--mod-statuslight-spacing-top-to-label,var(--spectrum-statuslight-spacing-top-to-label));padding-block-end:var(--mod-statuslight-spacing-bottom-to-label,var(--spectrum-statuslight-spacing-bottom-to-label));padding-inline:0;display:flex}:host(:lang(ja)),:host(:lang(ko)),:host(:lang(zh)){line-height:var(--mod-statuslight-line-height-cjk,var(--spectrum-statuslight-line-height-cjk))}:host:before{--spectrum-statuslight-spacing-computed-top-to-dot:calc(var(--mod-statuslight-spacing-top-to-dot,var(--spectrum-statuslight-spacing-top-to-dot)) - var(--mod-statuslight-spacing-top-to-label,var(--spectrum-statuslight-spacing-top-to-label)));content:"";inline-size:var(--mod-statuslight-dot-size,var(--spectrum-statuslight-dot-size));block-size:var(--mod-statuslight-dot-size,var(--spectrum-statuslight-dot-size));border-radius:var(--mod-statuslight-corner-radius,var(--spectrum-statuslight-corner-radius));flex-grow:0;flex-shrink:0;margin-block-start:var(--spectrum-statuslight-spacing-computed-top-to-dot);margin-inline-end:var(--mod-statuslight-spacing-dot-to-label,var(--spectrum-statuslight-spacing-dot-to-label));display:inline-block}:host([variant=neutral]){color:var(--highcontrast-statuslight-subdued-content-color-default,var(--mod-statuslight-subdued-content-color-default,var(--spectrum-statuslight-subdued-content-color-default)));font-style:italic}:host([variant=neutral]):before{background-color:var(--mod-statuslight-semantic-neutral-color,var(--spectrum-statuslight-semantic-neutral-color))}:host([variant=accent]):before{background-color:var(--mod-statuslight-semantic-accent-color,var(--spectrum-statuslight-semantic-accent-color))}:host([variant=info]):before{background-color:var(--mod-statuslight-semantic-info-color,var(--spectrum-statuslight-semantic-info-color))}:host([variant=negative]):before{background-color:var(--mod-statuslight-semantic-negative-color,var(--spectrum-statuslight-semantic-negative-color))}:host([variant=notice]):before{background-color:var(--mod-statuslight-semantic-notice-color,var(--spectrum-statuslight-semantic-notice-color))}:host([variant=positive]):before{background-color:var(--mod-statuslight-semantic-positive-color,var(--spectrum-statuslight-semantic-positive-color))}.spectrum-StatusLight--gray:before{background-color:var(--mod-statuslight-nonsemantic-gray-color,var(--spectrum-statuslight-nonsemantic-gray-color))}.spectrum-StatusLight--red:before{background-color:var(--mod-statuslight-nonsemantic-red-color,var(--spectrum-statuslight-nonsemantic-red-color))}.spectrum-StatusLight--orange:before{background-color:var(--mod-statuslight-nonsemantic-orange-color,var(--spectrum-statuslight-nonsemantic-orange-color))}:host([variant=yellow]):before{background-color:var(--mod-statuslight-nonsemantic-yellow-color,var(--spectrum-statuslight-nonsemantic-yellow-color))}:host([variant=chartreuse]):before{background-color:var(--mod-statuslight-nonsemantic-chartreuse-color,var(--spectrum-statuslight-nonsemantic-chartreuse-color))}:host([variant=celery]):before{background-color:var(--mod-statuslight-nonsemantic-celery-color,var(--spectrum-statuslight-nonsemantic-celery-color))}.spectrum-StatusLight--green:before{background-color:var(--mod-statuslight-nonsemantic-green-color,var(--spectrum-statuslight-nonsemantic-green-color))}:host([variant=seafoam]):before{background-color:var(--mod-statuslight-nonsemantic-seafoam-color,var(--spectrum-statuslight-nonsemantic-seafoam-color))}:host([variant=cyan]):before{background-color:var(--mod-statuslight-nonsemantic-cyan-color,var(--spectrum-statuslight-nonsemantic-cyan-color))}.spectrum-StatusLight--blue:before{background-color:var(--mod-statuslight-nonsemantic-blue-color,var(--spectrum-statuslight-nonsemantic-blue-color))}:host([variant=indigo]):before{background-color:var(--mod-statuslight-nonsemantic-indigo-color,var(--spectrum-statuslight-nonsemantic-indigo-color))}:host([variant=purple]):before{background-color:var(--mod-statuslight-nonsemantic-purple-color,var(--spectrum-statuslight-nonsemantic-purple-color))}:host([variant=fuchsia]):before{background-color:var(--mod-statuslight-nonsemantic-fuchsia-color,var(--spectrum-statuslight-nonsemantic-fuchsia-color))}:host([variant=magenta]):before{background-color:var(--mod-statuslight-nonsemantic-magenta-color,var(--spectrum-statuslight-nonsemantic-magenta-color))}@media (forced-colors:active){:host([dir]){--highcontrast-statuslight-content-color-default:CanvasText;--highcontrast-statuslight-subdued-content-color-default:CanvasText;forced-color-adjust:none}:host:before{forced-color-adjust:none;border:var(--mod-statuslight-border-width,var(--spectrum-statuslight-border-width))solid ButtonText}}:host([disabled]):before{background-color:var(--spectrum-statuslight-dot-color-disabled,var(--spectrum-gray-400))}
`;/* harmony default export */ __webpack_exports__["default"] = (s);
//# sourceMappingURL=status-light.css.js.map


/***/ }),

/***/ "./packages/status-light/stories/status-light.stories.js":
/*!***************************************************************!*\
  !*** ./packages/status-light/stories/status-light.stories.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   XL: function() { return /* binding */ XL; },
/* harmony export */   __namedExportsOrder: function() { return /* binding */ __namedExportsOrder; },
/* harmony export */   disabledTrue: function() { return /* binding */ disabledTrue; },
/* harmony export */   l: function() { return /* binding */ l; },
/* harmony export */   m: function() { return /* binding */ m; },
/* harmony export */   s: function() { return /* binding */ s; }
/* harmony export */ });
/* harmony import */ var _spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @spectrum-web-components/base */ "./tools/base/src/index.dev.js");
/* harmony import */ var _spectrum_web_components_status_light_sp_status_light_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @spectrum-web-components/status-light/sp-status-light.js */ "./packages/status-light/sp-status-light.dev.js");




/* harmony default export */ __webpack_exports__["default"] = ({
  component: "sp-status-light",
  title: "StatusLight"
});
const s = () => (0,_spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__.html)`
    <sp-status-light size="s" variant="accent">accent</sp-status-light>
    <sp-status-light size="s" variant="positive">positive</sp-status-light>
    <sp-status-light size="s" variant="negative">negative</sp-status-light>
    <sp-status-light size="s" variant="notice">notice</sp-status-light>
    <sp-status-light size="s" variant="info">info</sp-status-light>
    <sp-status-light size="s" variant="neutral">neutral</sp-status-light>
    <sp-status-light size="s" variant="yellow">yellow</sp-status-light>
    <sp-status-light size="s" variant="fuchsia">fuchsia</sp-status-light>
    <sp-status-light size="s" variant="indigo">indigo</sp-status-light>
    <sp-status-light size="s" variant="seafoam">seafoam</sp-status-light>
    <sp-status-light size="s" variant="chartreuse">chartreuse</sp-status-light>
    <sp-status-light size="s" variant="magenta">magenta</sp-status-light>
    <sp-status-light size="s" variant="celery">celery</sp-status-light>
    <sp-status-light size="s" variant="purple">purple</sp-status-light>
    <sp-status-light size="s" variant="cyan">cyan</sp-status-light>
`;
const m = () => (0,_spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__.html)`
    <sp-status-light size="m" variant="accent">accent</sp-status-light>
    <sp-status-light size="m" variant="positive">positive</sp-status-light>
    <sp-status-light size="m" variant="negative">negative</sp-status-light>
    <sp-status-light size="m" variant="notice">notice</sp-status-light>
    <sp-status-light size="m" variant="info">info</sp-status-light>
    <sp-status-light size="m" variant="neutral">neutral</sp-status-light>
    <sp-status-light size="m" variant="yellow">yellow</sp-status-light>
    <sp-status-light size="m" variant="fuchsia">fuchsia</sp-status-light>
    <sp-status-light size="m" variant="indigo">indigo</sp-status-light>
    <sp-status-light size="m" variant="seafoam">seafoam</sp-status-light>
    <sp-status-light size="m" variant="chartreuse">chartreuse</sp-status-light>
    <sp-status-light size="m" variant="magenta">magenta</sp-status-light>
    <sp-status-light size="m" variant="celery">celery</sp-status-light>
    <sp-status-light size="m" variant="purple">purple</sp-status-light>
    <sp-status-light size="m" variant="cyan">cyan</sp-status-light>
`;
const l = () => (0,_spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__.html)`
    <sp-status-light size="l" variant="accent">accent</sp-status-light>
    <sp-status-light size="l" variant="positive">positive</sp-status-light>
    <sp-status-light size="l" variant="negative">negative</sp-status-light>
    <sp-status-light size="l" variant="notice">notice</sp-status-light>
    <sp-status-light size="l" variant="info">info</sp-status-light>
    <sp-status-light size="l" variant="neutral">neutral</sp-status-light>
    <sp-status-light size="l" variant="yellow">yellow</sp-status-light>
    <sp-status-light size="l" variant="fuchsia">fuchsia</sp-status-light>
    <sp-status-light size="l" variant="indigo">indigo</sp-status-light>
    <sp-status-light size="l" variant="seafoam">seafoam</sp-status-light>
    <sp-status-light size="l" variant="chartreuse">chartreuse</sp-status-light>
    <sp-status-light size="l" variant="magenta">magenta</sp-status-light>
    <sp-status-light size="l" variant="celery">celery</sp-status-light>
    <sp-status-light size="l" variant="purple">purple</sp-status-light>
    <sp-status-light size="l" variant="cyan">cyan</sp-status-light>
`;
const XL = () => (0,_spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__.html)`
    <sp-status-light size="xl" variant="accent">accent</sp-status-light>
    <sp-status-light size="xl" variant="positive">positive</sp-status-light>
    <sp-status-light size="xl" variant="negative">negative</sp-status-light>
    <sp-status-light size="xl" variant="notice">notice</sp-status-light>
    <sp-status-light size="xl" variant="info">info</sp-status-light>
    <sp-status-light size="xl" variant="neutral">neutral</sp-status-light>
    <sp-status-light size="xl" variant="yellow">yellow</sp-status-light>
    <sp-status-light size="xl" variant="fuchsia">fuchsia</sp-status-light>
    <sp-status-light size="xl" variant="indigo">indigo</sp-status-light>
    <sp-status-light size="xl" variant="seafoam">seafoam</sp-status-light>
    <sp-status-light size="xl" variant="chartreuse">chartreuse</sp-status-light>
    <sp-status-light size="xl" variant="magenta">magenta</sp-status-light>
    <sp-status-light size="xl" variant="celery">celery</sp-status-light>
    <sp-status-light size="xl" variant="purple">purple</sp-status-light>
    <sp-status-light size="xl" variant="cyan">cyan</sp-status-light>
`;
const disabledTrue = () => (0,_spectrum_web_components_base__WEBPACK_IMPORTED_MODULE_0__.html)`
    <sp-status-light variant="positive" disabled>positive</sp-status-light>
`;
disabledTrue.storyName = "disabled: true";
//# sourceMappingURL=status-light.stories.js.map
;
const __namedExportsOrder = ["s", "m", "l", "XL", "disabledTrue"];
s.parameters = {
  ...s.parameters,
  docs: {
    ...s.parameters?.docs,
    source: {
      originalSource: "() => html`\n    <sp-status-light size=\"s\" variant=\"accent\">accent</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"positive\">positive</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"negative\">negative</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"notice\">notice</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"info\">info</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"neutral\">neutral</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"yellow\">yellow</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"fuchsia\">fuchsia</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"indigo\">indigo</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"seafoam\">seafoam</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"chartreuse\">chartreuse</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"magenta\">magenta</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"celery\">celery</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"purple\">purple</sp-status-light>\n    <sp-status-light size=\"s\" variant=\"cyan\">cyan</sp-status-light>\n`",
      ...s.parameters?.docs?.source
    }
  }
};
m.parameters = {
  ...m.parameters,
  docs: {
    ...m.parameters?.docs,
    source: {
      originalSource: "() => html`\n    <sp-status-light size=\"m\" variant=\"accent\">accent</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"positive\">positive</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"negative\">negative</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"notice\">notice</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"info\">info</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"neutral\">neutral</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"yellow\">yellow</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"fuchsia\">fuchsia</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"indigo\">indigo</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"seafoam\">seafoam</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"chartreuse\">chartreuse</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"magenta\">magenta</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"celery\">celery</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"purple\">purple</sp-status-light>\n    <sp-status-light size=\"m\" variant=\"cyan\">cyan</sp-status-light>\n`",
      ...m.parameters?.docs?.source
    }
  }
};
l.parameters = {
  ...l.parameters,
  docs: {
    ...l.parameters?.docs,
    source: {
      originalSource: "() => html`\n    <sp-status-light size=\"l\" variant=\"accent\">accent</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"positive\">positive</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"negative\">negative</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"notice\">notice</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"info\">info</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"neutral\">neutral</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"yellow\">yellow</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"fuchsia\">fuchsia</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"indigo\">indigo</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"seafoam\">seafoam</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"chartreuse\">chartreuse</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"magenta\">magenta</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"celery\">celery</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"purple\">purple</sp-status-light>\n    <sp-status-light size=\"l\" variant=\"cyan\">cyan</sp-status-light>\n`",
      ...l.parameters?.docs?.source
    }
  }
};
XL.parameters = {
  ...XL.parameters,
  docs: {
    ...XL.parameters?.docs,
    source: {
      originalSource: "() => html`\n    <sp-status-light size=\"xl\" variant=\"accent\">accent</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"positive\">positive</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"negative\">negative</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"notice\">notice</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"info\">info</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"neutral\">neutral</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"yellow\">yellow</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"fuchsia\">fuchsia</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"indigo\">indigo</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"seafoam\">seafoam</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"chartreuse\">chartreuse</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"magenta\">magenta</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"celery\">celery</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"purple\">purple</sp-status-light>\n    <sp-status-light size=\"xl\" variant=\"cyan\">cyan</sp-status-light>\n`",
      ...XL.parameters?.docs?.source
    }
  }
};
disabledTrue.parameters = {
  ...disabledTrue.parameters,
  docs: {
    ...disabledTrue.parameters?.docs,
    source: {
      originalSource: "() => html`\n    <sp-status-light variant=\"positive\" disabled>positive</sp-status-light>\n`",
      ...disabledTrue.parameters?.docs?.source
    }
  }
};

/***/ })

}]);
//# sourceMappingURL=status-light-stories-status-light-stories.iframe.bundle.js.map